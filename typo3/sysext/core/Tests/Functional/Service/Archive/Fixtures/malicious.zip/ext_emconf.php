<?php
$EM_CONF['zip'] = [
    'title' => 'Trustworthy',
    'description' => 'This is a totally trustworthy TYPO3 extension',
    'category' => 'plugin',
    'state' => 'stable',
    'constraints' => [
        'depends' => [],
        'conflicts' => [],
        'suggests' => [],
    ],
];
